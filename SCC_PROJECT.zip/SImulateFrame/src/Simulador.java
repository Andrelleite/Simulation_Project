public class Simulador {

 	// Rel-gio de simula--o - vari-vel que cont-m o valor do tempo em cada instante
        private double instante;
        private double tempo;
    // M-dias das distribui--es de chegadas e de atendimento no servi-o
	// N-mero de clientes que v-o ser atendidos
	private int n_clientes;
	// Servi-o - pode haver mais do que um num simulador
        private Servico publicSection, businessSection;
    // Lista de eventos - onde ficam registados todos os eventos que v-o ocorrer na simula--o
    // Cada simulador s- tem uma
	private ListaEventos lista;
	private NumerosMagicos var;
        private double sym_time;
        public String results_p;
        public String results_b;

    // Construtor
    public Simulador(int clientes, int tempo) {
        // Inicializa--o de par-metros do simulador
        n_clientes = clientes;
        sym_time = tempo;
        instante = 0;
	var = new NumerosMagicos();
        
	// Cria--o do servi-o
	publicSection = new Servico (this, 0, 2, var);
	businessSection = new Servico (this, 1, 1, var);
	// Cria--o da lista de eventos
	lista = new ListaEventos(this);
	// Agendamento da primeira chegada
        // Se n-o for feito, o simulador n-o tem eventos para simular
        insereEvento (new Chegada(instante, this, 'p', publicSection, businessSection));
        insereEvento (new Chegada(instante, this, 'b', publicSection, businessSection));

        
        
    }

        // programa principal
        public static void main(String[] args) {
            // Cria um simulador e
            
        }

    // M-todo que insere o evento e1 na lista de eventos
	void insereEvento (Evento e1){
                lista.insereEvento (e1);    
	}

    // M-todo que actualiza os valores estat-sticos do simulador
	private void act_stats(){
		publicSection.act_stats();
		businessSection.act_stats();
	}

    // M-todo que apresenta os resultados de simula--o finais
	private void relat (){
            
            this.results_p = publicSection.relat();
            this.results_b = businessSection.relat();
           
            
            System.out.println();
            System.out.println("------- Resultados finais -------\n\nSECÇÃO PUBLICA:\n"+results_p+"\n");
		System.out.println("--------------\n\nSECÇÃO BUSINESS:"+results_b+"\n");
	}
        
        
    // M-todo executivo do simulador
	public void executa (){
		Evento e1;
                double t = 0;
		// Enquanto n-o atender todos os clientes
                if(this.n_clientes > 0){
                    while ((publicSection.getAtendidos()+businessSection.getAtendidos()) < n_clientes){
                //	lista.print();  // Mostra lista de eventos - desnecess-rio; - apenas informativo
			e1 = (Evento)(lista.removeFirst());  // Retira primeiro evento (- o mais iminente) da lista de eventos
			instante = e1.getInstante();         // Actualiza rel-gio de simula--o
			act_stats(); 
			e1.executa(var.getCliente(e1.type));              // Executa evento
                    };
                }
                
                else if(this.n_clientes ==  0){
                    System.out.println(this.sym_time);
                    while ( t < this.sym_time){

                //	lista.print();  // Mostra lista de eventos - desnecess-rio; - apenas informativo
			e1 = (Evento)(lista.removeFirst());  // Retira primeiro evento (- o mais iminente) da lista de eventos
			instante = e1.getInstante();         // Actualiza rel-gio de simula--o
			act_stats(); 
			e1.executa(var.getCliente(e1.type));              // Executa evento
                        t = e1.instante;
                    };       
                }
		relat();  // Apresenta resultados de simula--o finais
	}

    // M-todo que devolve o instante de simula--o corrente
    public double getInstante() {
        return instante;
    }
}