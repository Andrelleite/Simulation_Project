// Classe que representa a sa-da de um cliente. Deriva de Evento.

public class Saida extends Evento {
    public int removed; //diz se a saída foi cancelada
    public Servico serv;
	//Construtor
	Saida (double i, Simulador s, Servico serv, char type){
        super(i, s, type);
        removed=0;
        this.serv = serv;
	}

	// M-todo que executa as ac--es correspondentes - sa-da de um cliente
	void executa (double media){
        // Retira cliente do servi-o
        if(removed==0)
            serv.removeServico();
    }

    // M-todo que descreve o evento.
    // Para ser usado na listagem da lista de eventos.
    public String toString(){
         return "Sa-da em " + instante;
    }


}
