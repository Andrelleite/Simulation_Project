public class NumerosMagicos {
    private double media_pub = 30;
    private double media_biz = 20;
    private double std_pub = 8;
    private double std_biz = 4;
    private double media_pub_alt = 23;
    private double media_biz_alt = 25;
    private double std_alt = 5;
    private double client_pub = 12;
    private double client_biz = 35;
    private double[] current_rand = {-1, -1, -1, -1};
    private int[] seeds = {48, 83, 23, 59};

    public double getMedia(int type){
        if(type == 1)
            return this.media_biz;
        else
            return this.media_pub;
    }

    public double getMediaAlt(int type){
        if(type == 1)
            return this.media_biz_alt;
        else
            return this.media_pub_alt;
    }

    public double getStd(int type){
        if(type == 1)
            return this.std_biz;
        else
            return this.std_pub;
    }

    public double getStdAlt(){
        return this.std_alt;
    }

    public double getCliente(char type){
        if(type=='b')
            return this.client_biz;
        else
            return this.client_pub;
    }

    public boolean hasRand(int pos){
        return (this.current_rand[pos]!=-1);
    }

    public double getRand(int pos){
        double retval = this.current_rand[pos];
        this.current_rand[pos] = -1;
        return retval;
    }

    public void insertRand(int pos, double rand){
        this.current_rand[pos] = rand;
    }

    public int getSeed(int pos){
        return seeds[pos];
    }
}