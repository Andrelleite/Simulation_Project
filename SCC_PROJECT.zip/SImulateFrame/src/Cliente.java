// Classe que representa um cliente
// Como s-o indistintos neste exemplo, est- vazia

public class Cliente {
    public char type; //tipo de cliente (p para publico, b para business)
    Cliente(char t){
        type = t;
    }
}