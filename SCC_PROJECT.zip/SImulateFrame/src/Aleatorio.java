// Classe para gera--o de n-meros aleat-rios segundos v-rias distribui--es
// Apenas a distribui--o exponencial negativa est- definida

public class Aleatorio {

	// Gera um n-mero segundo uma distribui--o exponencial negativa de m-dia m
    static double exponencial (double m){
		return (-m*Math.log(RandomGenerator.rand(10)));
	}

    
 

public static double [] distribuicao_normal(double media, double desvio, int seed)
{
    double Variavel1, Variavel2, W, X1, X2;
    
    do{
        do{
            Variavel1 = 2*RandomGenerator.rand(seed)-1;
            Variavel2 = 2*RandomGenerator.rand(seed)-1;
            W = Math.pow(Variavel1,2) + Math.pow(Variavel2,2);
        }while (W>1);
        
        double R1, R2;
        
        R1 = Variavel1 * Math.pow((-2 * Math.log(W)/W), 0.5);
        R2 = Variavel2 * Math.pow((-2 * Math.log(W)/W), 0.5);
        
        X1 = media + R1*desvio;
        X2 = media + R2*desvio;
        
    }while (X1<0 || X2<0);
    
    double [] array = new double [2];
    array[0]= X1;
    array[1]= X2;
    
    return array;
}
    
}