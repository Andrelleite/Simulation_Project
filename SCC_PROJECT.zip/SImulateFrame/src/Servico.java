import java.util.*;

// Classe que representa um servi-o com uma fila de espera associada

public class Servico {
	private int estado; // Vari-vel que regista o estado do servi-o: 0 - livre; 1 - ocupado
        private int atendidos; // N-mero de clientes atendidos at- ao momento
	private double temp_ult, soma_temp_esp, soma_temp_serv; // Vari-veis para c-lculos estat-sticos
	private Vector<Cliente> fila; // Fila de espera do servi-o
	private Simulador s; // Refer-ncia para o simulador a que pertence o servi-o
	private int typeServ;
	private int maxEst;
	private char[] current = new char[10];
	private ListaEventos saidas;
	private NumerosMagicos var;
        public double tempoFinal;
	// Construtor
    Servico (Simulador s, int typeServ, int maxEst, NumerosMagicos var){
		this.s = s;
		fila = new Vector <Cliente>(); // Cria fila de espera
		estado = 0; // Livre
		temp_ult = s.getInstante(); // Tempo que passou desde o -ltimo evento. Neste caso 0, porque a simula--o ainda n-o come-ou.
		atendidos = 0;  // Inicializa--o de vari-veis
		soma_temp_esp = 0;
		soma_temp_serv = 0;
		this.maxEst = maxEst;
		this.saidas = new ListaEventos(s);
		this.var = var;
		this.typeServ = typeServ;
	}

	private double genValue(double media, double std, int typeBuffer){
		int pos = this.typeServ + typeBuffer;
		if(var.hasRand(pos)){
			return var.getRand(pos);
		} else {
			double [] vars = Aleatorio.distribuicao_normal(media, std, var.getSeed(pos));
			var.insertRand(pos, vars[1]);
			return vars[0];
		}
	}

	// M-todo que insere cliente (c) no servi-o
    public void insereServico (Cliente c){
		if (estado < maxEst ) { // Se servi-o livre,
			estado ++;     // fica ocupado e
			current[estado] = c.type;
			// agenda sa-da do cliente c para daqui a s.getMedia_serv() instantes
			if(this.typeServ == 0){
				if(c.type=='p'){ //cliente publico na fila publica
					s.insereEvento (new Saida(s.getInstante()+genValue(var.getMedia(this.typeServ), var.getStd(this.typeServ), 0), s, this, c.type));
				} else { //cliente business na fila publica
					s.insereEvento (new Saida(s.getInstante()+genValue(var.getMediaAlt(this.typeServ), var.getStdAlt(), 2), s, this, c.type));
				}
			} else {
				if(c.type=='b') //cliente business na fila business
					s.insereEvento (new Saida(s.getInstante()+genValue(var.getMedia(this.typeServ), var.getStd(this.typeServ), 0), s, this, c.type));
				else { //cliente publico na fila business (pode ser removido)
					Saida saida_p = new Saida(s.getInstante()+genValue(var.getMediaAlt(this.typeServ), var.getStdAlt(), 2), s, this, c.type);
					s.insereEvento (saida_p);
					this.saidas.insereEvento (saida_p);
				}
			}
		}
		else{ 
			fila.addElement(c);
		} // Se servi-o ocupado, o cliente vai para a fila de espera
	}

	// M-todo que remove cliente do servi-o
    public void removeServico (){
		atendidos++; // Regista que acabou de atender + 1 cliente
		if (fila.size()== 0) estado --; // Se a fila est- vazia, liberta o servi-o
		else { // Se n-o,
		     // vai buscar pr-ximo cliente - fila de espera e
			 Cliente c = (Cliente)fila.firstElement();
			 fila.removeElementAt(0);
			 current[estado] = c.type;
			 // agenda a sua saida para daqui a s.getMedia_serv() instantes
			 s.insereEvento (new Saida(s.getInstante()+genValue(var.getMedia(this.typeServ), var.getStd(this.typeServ), 0),s, this, c.type));
		}
	}

	public char currClient(){
		return current[0];
	}

	public void cancelServico(){
		this.estado = 0;
		this.current[0] = 'b';
		this.saidas.removeSaidasPublicas();
	}
	// M-todo que calcula valores para estat-sticas, em cada passo da simula--o ou evento
    public void act_stats(){
        // Calcula tempo que passou desde o -ltimo evento
		double temp_desde_ult = s.getInstante() - temp_ult;
		// Actualiza vari-vel para o pr-ximo passo/evento
		temp_ult = s.getInstante();
		// Contabiliza tempo de espera na fila
		// para todos os clientes que estiveram na fila durante o intervalo
		soma_temp_esp += fila.size() * temp_desde_ult;
		// Contabiliza tempo de atendimento
		soma_temp_serv += estado * temp_desde_ult;
	}

	// M-todo que calcula valores finais estat-sticos
    public String relat (){
                String result;
        // Tempo m-dio de espera na fila
		double temp_med_fila = soma_temp_esp / (atendidos+fila.size());
		// Comprimento m-dio da fila de espera
		// s.getInstante() neste momento - o valor do tempo de simula--o,
        // uma vez que a simula--o come-ou em 0 e este m-todo s- - chamdo no fim da simula--o
		double comp_med_fila = soma_temp_esp / s.getInstante();
		// Tempo m-dio de atendimento no servi-o
		double utilizacao_serv = soma_temp_serv / s.getInstante();
		// Apresenta resultados
                this.tempoFinal = s.getInstante();
                
		result = "Tempo médio de espera "+temp_med_fila+'\n';
		result += "Comp. médio da fila "+comp_med_fila+'\n';
		result += "Utilização do serviço "+utilizacao_serv/maxEst+'\n';
		result += "Tempo de simulação "+this.tempoFinal+'\n'; // Valor actual
		result += "Número de clientes atendidos "+atendidos+'\n';
		result += "Número de clientes na fila "+fila.size()+'\n'; // Valor actual
                
                return result;
                
	}

    // M-todo que devolve o n-mero de clientes atendidos no servi-o at- ao momento
    public int getAtendidos() {
        return atendidos;
	}
	
	public boolean livre() {
		return (estado < maxEst);
	}

}